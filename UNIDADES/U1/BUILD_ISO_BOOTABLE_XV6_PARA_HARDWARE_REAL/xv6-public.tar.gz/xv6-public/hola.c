/*#include <stdio.h>*/
#include "types.h"
#include "user.h"
int main(int argc,char *argv[])
{
  printf(1,"Hola Mundo!\n");
  /*return 0;*/
  exit();
}
